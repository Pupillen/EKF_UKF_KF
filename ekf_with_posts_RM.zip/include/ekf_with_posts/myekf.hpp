/*** 
 * @Author: ztr
 * @Date: 2022-02-26 22:43:09
 * @LastEditTime: 2022-02-27 11:37:50
 * @LastEditors: ztr
 * @Description: 
 * @FilePath: /RMUA2022/src/robot_localization/ekf_with_posts/include/ekf_with_posts/myekf.hpp
 */
#include <iostream>
#include <fstream>
#include <cassert>
#include <string>
#include "ekf.hpp"
#include <eigen3/Eigen/Geometry>
using namespace my_filter;
class MyEKF : public EKF
{
public:
  MyEKF(string logname="log.txt"):EKF(logname)
  {cout<<"MyEKF构造"<<endl;}
  ~MyEKF()
  {cout<<"MyEKF析构"<<endl;}
  virtual VectorXd f(const VectorXd &x, const VectorXd &u)
  {
    VectorXd pxpy_predict(nOutputs_); // 麦轮 运动学模型
    pxpy_predict(0) = x(0) + (u(0) * cos(u(2)) - u(1) * sin(u(2))) * 0.01;
    pxpy_predict(1) = x(1) + (u(0) * sin(u(2)) + u(1) * cos(u(2))) * 0.01;
    return pxpy_predict;
  }

  virtual VectorXd h(const VectorXd &x)
  {
    VectorXd px_py_measure(nOutputs_);
    px_py_measure(0) = x(0);
    px_py_measure(1) = x(1);
    return px_py_measure;
  }

private:
    double dt;
  /* static double dt=0.01; */
};
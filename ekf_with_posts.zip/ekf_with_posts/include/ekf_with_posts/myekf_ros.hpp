/*** 
 * @Author: ztr
 * @Date: 2022-02-26 22:49:21
 * @LastEditTime: 2022-02-27 00:05:11
 * @LastEditors: ztr
 * @Description: 
 * @FilePath: /RMUA2022/src/robot_localization/ekf_with_posts/include/ekf_with_posts/myekf_ros.hpp
 */
#include <ros/ros.h>
#include <iostream>
#include <geometry_msgs/PoseStamped.h>
#include <ros/console.h>
#include <nav_msgs/Odometry.h>
#include <eigen3/Eigen/Core>
#include "myekf.hpp"
#include <eigen3/Eigen/Geometry>
#ifndef MYEKF_ROS_HPP
#define MYEKF_ROS_HPP
using namespace my_filter;
using namespace std;
using namespace Eigen;
class myekf_ros
{
private:
    MyEKF myekf;//!!!!!!!!注意运动学模型里面定死了dt=0.01如果需要重新制定发布频率，考虑重新修改
    ros::NodeHandle nh;
    ros::Subscriber posts_info;//订阅posts即p  geometry_msgs::PoseStamped
    ros::Subscriber odom_info;//订阅odom
    ros::Publisher  odom_ekf_pb;//发布odom_ekf
    geometry_msgs::PoseStamped p_xy;//收到的哨岗数据
    nav_msgs::Odometry ekf_odom;//发布的ekf_odom
    bool initialized;
    double yaw;//储存yaw
    ros::Timer timer;//回调timer_callBack
    Matrix2d Q;//底盘数据x,y协方差矩阵
    Matrix2d R;//哨岗数据x,y协方差矩阵
    Vector2d x0;//记录初始底盘数据
    Vector3d input;//EKF中输入即u
    Vector2d pxpy;//EKF中状态变量即x
    Vector2d pxpy_ekf;//EKF估计出来的xy
public:
    myekf_ros(const Matrix2d& Q,const Matrix2d& R);
    ~myekf_ros();
    void posts_callback(const geometry_msgs::PoseStampedConstPtr &pose_xy);//后期需要改成geometry_msgs/PointStamped类型真正哨岗
	void odom_callback(const nav_msgs::OdometryConstPtr &odom_);
    void timer_callBack(const ros::TimerEvent& event);//发布ekf_odom
    void pub_and_sub();//管理主要算法
    void initmyekf(const Matrix2d& Q,const Matrix2d& R,const Vector2d& x0);//传入myekf作初始化工作
    
};
#endif



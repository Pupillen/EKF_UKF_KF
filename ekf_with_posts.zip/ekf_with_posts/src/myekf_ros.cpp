/***
 * @Author: ztr
 * @Date: 2022-02-26 22:49:39
 * @LastEditTime: 2022-02-26 23:34:45
 * @LastEditors: ztr
 * @Description:
 * @FilePath: /RMUA2022/src/robot_localization/ekf_with_posts/src/myekf_ros.cpp
 */
/***
 * @Author: ztr
 * @Date: 2022-02-26 22:49:39
 * @LastEditTime: 2022-02-26 23:16:43
 * @LastEditors: ztr
 * @Description:
 * @FilePath: /RMUA2022/src/robot_localization/ekf_with_posts/src/myekf_ros.cpp
 */
#include <ros/ros.h>
#include <iostream>
#include <geometry_msgs/PoseStamped.h>
#include <ros/console.h>
#include <nav_msgs/Odometry.h>
#include <eigen3/Eigen/Core>
#include "myekf_ros.hpp"
#include "tf/transform_datatypes.h" //转换函数头文件
using namespace my_filter;
using namespace std;
using namespace Eigen;
myekf_ros::myekf_ros(const Matrix2d &Q_, const Matrix2d &R_):Q(Q_), R(R_)
{
}

myekf_ros::~myekf_ros()
{
}
void myekf_ros::pub_and_sub()
{
    posts_info = nh.subscribe("/posts_pose", 10, &myekf_ros::posts_callback, this, ros::TransportHints().tcpNoDelay());
    odom_info = nh.subscribe("/odom", 10, &myekf_ros::odom_callback, this, ros::TransportHints().tcpNoDelay());
    odom_ekf_pb = nh.advertise<nav_msgs::Odometry>("/odom_ekf", 10);
    timer = nh.createTimer(ros::Duration(0.01), &myekf_ros::timer_callBack,this);
}
void myekf_ros::initmyekf(const Matrix2d &Q, const Matrix2d &R, const Vector2d &x0) //传入myekf作初始化工作
{
    ROS_INFO("initializing...");
    myekf.InitSystem(2, 2, Q, R);
    myekf.InitSystemState(x0);
    initialized = true;
}
//得到linear.x,linear.y,yaw构成u输入变量
void myekf_ros::odom_callback(const nav_msgs::OdometryConstPtr &odom_)
{
    if (!initialized)
    {
        x0 << odom_->pose.pose.position.x, odom_->pose.pose.position.y; //记录初始odom的x,y
        initmyekf(Q, R, x0);
        return;
    }
    ekf_odom = *odom_;
    tf::Quaternion quat;
    tf::quaternionMsgToTF((*odom_).pose.pose.orientation, quat);
    double roll, pitch;                           //定义存储r\p\y的容器
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw); //进行转换
    input << odom_->twist.twist.linear.x, odom_->pose.pose.position.y, yaw;
}
void myekf_ros::posts_callback(const geometry_msgs::PoseStampedConstPtr &pose_xy)
{
    pxpy << pose_xy->pose.position.x, pose_xy->pose.position.y;
}
void myekf_ros::timer_callBack(const ros::TimerEvent &event)
{
    myekf.EKalmanf(pxpy, input);
    pxpy_ekf = myekf.GetCurrentEstimatedOutput();
    ekf_odom.pose.pose.position.x = pxpy_ekf(0);
    ekf_odom.pose.pose.position.y = pxpy_ekf(1);
    ekf_odom.header.stamp = ros::Time::now();
    odom_ekf_pb.publish(ekf_odom);
}
/*** 
 * @Author: ztr
 * @Date: 2022-02-26 23:51:22
 * @LastEditTime: 2022-02-27 00:20:31
 * @LastEditors: ztr
 * @Description: 
 * @FilePath: /RMUA2022/src/robot_localization/ekf_with_posts/src/ekf_posts.cpp
 */
/***
 * @Author: ztr
 * @Date: 2022-02-26 23:51:22
 * @LastEditTime: 2022-02-26 23:59:00
 * @LastEditors: ztr
 * @Description:
 * @FilePath: /RMUA2022/src/robot_localization/ekf_with_posts/src/ekf_posts.cpp
 */
#include <ros/ros.h>
#include "myekf_ros.hpp"
int main(int argc, char *argv[])
{ //注意在EKF类实现当中P_m初始值设置的为I单位矩阵；
    using namespace my_filter;
    using namespace std;
    using namespace Eigen;
    ros::init(argc,argv,"ekf_posts");
    ros::NodeHandle nh_("~");
    double dt, Qxx, Qyy, Rxx, Ryy; //假设为对角矩阵
    nh_.param("Q_xx", Qxx, 0.05);
    nh_.param("Q_yy", Qyy, 0.05);
    nh_.param("R_xx", Rxx, 0.05);
    nh_.param("R_yy", Ryy, 0.05);
    Matrix2d Q;          // Process noise covariance
    Matrix2d R;          // Measurement noise covariance
    Q << Qxx, 0, 0, Qyy; // 2*2 px py协方差
    R << Rxx, 0, 0, Ryy; //哨岗提供数据的协方差
    myekf_ros ekf_with_posts(Q,R);
    ros::spin();
    return 0;
}
